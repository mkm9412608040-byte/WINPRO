
import React from 'react';
import { motion } from 'framer-motion';
import { Gamepad2, Gift, Trophy } from 'lucide-react';

export default function App() {
  const games = [
    { name: 'Ludo', icon: '🎲', color: 'bg-yellow-200' },
    { name: 'Cricket', icon: '🏏', color: 'bg-green-200' },
    { name: 'Carrom', icon: '🎯', color: 'bg-pink-200' },
    { name: 'Quiz', icon: '❓', color: 'bg-blue-200' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-500 to-indigo-600 text-white p-4">
      <header className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Gamepad2 /> PlayHub
        </h1>
        <button className="bg-yellow-400 text-black px-4 py-2 rounded-full font-bold">
          Wallet: ₹500
        </button>
      </header>

      <section className="mb-6">
        <h2 className="text-xl font-semibold mb-3 flex items-center gap-2">
          <Gift /> Offers
        </h2>
        <motion.div
          className="bg-white text-black rounded-xl p-4 shadow-lg"
          whileHover={{ scale: 1.05 }}
        >
          Deposit ₹100 and get ₹50 bonus!
        </motion.div>
      </section>

      <section>
        <h2 className="text-xl font-semibold mb-3 flex items-center gap-2">
          <Trophy /> Games
        </h2>
        <div className="grid grid-cols-2 gap-4">
          {games.map((game, i) => (
            <motion.div
              key={i}
              className={`rounded-xl p-6 text-center text-black shadow-lg ${game.color}`}
              whileHover={{ scale: 1.05 }}
            >
              <div className="text-4xl">{game.icon}</div>
              <div className="mt-2 font-bold">{game.name}</div>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
